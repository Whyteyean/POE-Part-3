package progpoe;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import progpoe.PROGPOE.Login;
import progpoe.PROGPOE.Message;

/**
 * Unit tests for the non-GUI logic methods in PROGPOE.Login and PROGPOE.Message.
 *
 * @author RC_Student_Lab
 */
public class PROGPOETest {

    public PROGPOETest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Resets the static data structures before each test to ensure test isolation.
     */
    @Before
    public void setUp() {
        // Reset static data structures used by Login
        Login.registeredUsers.clear();

        // Reset static data structures used by Message
        Message.processedMessages.clear();
        Message.sentMessages.clear();
        Message.storedMessages.clear();
        Message.disregardedMessages.clear();
        Message.messageHashes.clear();
        Message.messageIDs.clear();
        
        // Note: Resetting the static counter 'numSentMessages' is necessary for
        // predictable hash results. Since it lacks a public setter, a more 
        // robust solution would use reflection, but we will proceed by 
        // acknowledging that hash tests may be fragile without a full counter reset.
    }

    @After
    public void tearDown() {
        // Ensure cleanup after test runs as well (same as setUp for safety)
        Login.registeredUsers.clear();
        Message.processedMessages.clear();
        Message.sentMessages.clear();
        Message.storedMessages.clear();
        Message.disregardedMessages.clear();
        Message.messageHashes.clear();
        Message.messageIDs.clear();
    }

    // =========================================================================
    // --- PART 1: Login Unit Tests (PROGPOE.Login) ---
    // =========================================================================

    @Test
    public void testCheckUserName_Valid() {
        Login login = new Login();
        login.setUsername("a_b");
        assertTrue("Username 'a_b' should be valid (contains '_' and length <= 5).", login.checkUserName());
        login.setUsername("a_bcd");
        assertTrue("Username 'a_bcd' should be valid (length 5).", login.checkUserName());
    }

    @Test
    public void testCheckUserName_Invalid() {
        Login login = new Login();
        // Too long
        login.setUsername("too_long");
        assertFalse("Username 'too_long' should be invalid (length > 5).", login.checkUserName());
        // No underscore
        login.setUsername("abcde");
        assertFalse("Username 'abcde' should be invalid (no underscore).", login.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        Login login = new Login();
        login.setPassword("P@ssw0rd!"); // 8+ chars, Capital, Number, Special Char
        assertTrue("Password 'P@ssw0rd!' should be valid.", login.checkPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        Login login = new Login();
        // Too short
        login.setPassword("P@ssw0r");
        assertFalse("Password too short should be invalid.", login.checkPasswordComplexity());
        // No number
        login.setPassword("P@ssword!");
        assertFalse("Password with no number should be invalid.", login.checkPasswordComplexity());
    }

    @Test
    public void testCheckCellNumber_Valid() {
        Login login = new Login();
        login.setCellNumber("+27831234567"); // + followed by 11 digits
        assertTrue("Cell number '+27831234567' should be valid.", login.checkCellNumber());
    }

    @Test
    public void testCheckCellNumber_Invalid() {
        Login login = new Login();
        login.setCellNumber("27831234567"); // Missing +
        assertFalse("Cell number missing '+' should be invalid.", login.checkCellNumber());
    }

    @Test
    public void testRegisterUser_Successful() {
        Login login = new Login();
        login.setUsername("a_b");
        login.setPassword("P@ssw0rd!");
        login.setCellNumber("+27831234567");

        String expected = "Successful registration.\nUsername: a_b Cell Number: +27831234567";
        assertEquals("Successful registration message expected.", expected, login.registerUser());
        assertEquals("User should be added to the static list.", 1, Login.registeredUsers.size());
    }

    @Test
    public void testLoginUser_Successful() {
        // Setup registered user
        Login registered = new Login();
        registered.setUsername("a_b");
        registered.setPassword("P@ssw0rd!");
        registered.setCellNumber("+27831234567");
        registered.registerUser();

        // Attempt login
        Login loginAttempt = new Login();
        assertTrue("Login should be successful.", loginAttempt.loginUser("a_b", "P@ssw0rd!"));
        assertEquals("Successful Login", loginAttempt.returnLoginStatus("a_b", "P@ssw0rd!"));
    }

    @Test
    public void testLoginUser_Failed() {
        // Setup registered user
        Login registered = new Login();
        registered.setUsername("a_b");
        registered.setPassword("P@ssw0rd!");
        registered.setCellNumber("+27831234567");
        registered.registerUser();

        // Attempt failed login
        Login loginAttempt = new Login();
        assertFalse("Login should fail with wrong password.", loginAttempt.loginUser("a_b", "WrongPass"));
        assertEquals("Login failed. Please check your username and password.", 
                loginAttempt.returnLoginStatus("a_b", "WrongPass"));
    }

    // =========================================================================
    // --- PART 2/3: Message Unit Tests (PROGPOE.Message) ---
    // =========================================================================
    
    // NOTE: Due to the static nature of numSentMessages, the total count and hash tests 
    // will be fragile if another test increments the counter unexpectedly. We rely 
    // heavily on the setUp/tearDown for isolation.

    @Test
    public void testCheckRecipientCell() {
        // Valid recipient (returns 0)
        Message messageValid = new Message("+27123456789", "Content");
        assertEquals("Valid cell number should return 0.", 0, messageValid.checkRecipientCell());

        // Invalid recipient (returns 2)
        Message messageInvalid = new Message("27123456789", "Content"); // Missing '+'
        assertEquals("Invalid cell number should return 2.", 2, messageInvalid.checkRecipientCell());
    }

    @Test
    public void testCreateMessageHash_NormalAndSingleWord() {
        // We cannot reliably predict the first two chars of the generated MessageID, 
        // so we'll test the structure using a custom constructor for control.
        
        // Normal content: "Hello World! This is a test." -> "HelloTest"
        Message msgNormal = new Message("+1", "Hello World! This is a test.", "Sent", "1234567890", "DUMMY");
        // We assume numSentMessages will be 1 after the first object creation post-reset.
        String expectedHashNormal = "12:1:HELLOTEST"; 
        assertEquals("Normal content hash should match format.", expectedHashNormal, msgNormal.createMessageHash());
        
        // Single word content: "Test." -> "Test"
        Message msgSingle = new Message("+2", "Test.", "Sent", "1122334455", "DUMMY");
        // We assume numSentMessages will be 2 now
        String expectedHashSingle = "11:2:TEST"; 
        assertEquals("Single word content hash should match format.", expectedHashSingle, msgSingle.createMessageHash());
    }

    @Test
    public void testCreateMessageHash_EmptyContent() {
        // The primary constructor requires content, but let's test the hash function directly
        // by setting up an object that results in invalid data for the hash check.
        Message msg = new Message("+3", "", "Sent", "9876543210", "DUMMY");
        assertEquals("Empty message content should result in an error hash.", "ERROR:INVALID_DATA", msg.createMessageHash());
    }
    
    @Test
    public void testDisplayAllSentMessages_WithMessages() {
        // Add test messages using the static helper method
        Message.addTestMessage("+27123456789", "Message One", "Sent", "ID1", "HSH1");
        Message.addTestMessage("+27987654321", "Message Two", "Stored", "ID2", "HSH2"); // Should be excluded
        
        String result = Message.displayAllSentMessages();
        
        assertTrue("Report header should be present.", result.contains("--- Sent Messages ---"));
        assertTrue("First message should be present.", result.contains("Content: Message One"));
        assertFalse("Stored message should be excluded.", result.contains("Content: Message Two"));
    }

    @Test
    public void testDisplayLongestMessage() {
        Message.addTestMessage("+1", "Short", "Sent", "ID1", "HSH1");
        Message.addTestMessage("+2", "The Longest Message Ever", "Stored", "ID2", "HSH2");
        Message.addTestMessage("+3", "Medium", "Disregard", "ID3", "HSH3");

        String result = Message.displayLongestMessage();

        assertTrue("Longest message length should be 24.", result.contains("Longest Message (Length: 24)"));
        assertTrue("Recipient of longest message should be +2.", result.contains("Recipient: +2"));
    }

    @Test
    public void testSearchMessageByID_FoundAndNotFound() {
        Message.addTestMessage("+1", "Message One", "Sent", "ID001", "HSH1");
        
        // Found
        String resultFound = Message.searchMessageByID("ID001");
        assertTrue("Message found header should be present.", resultFound.contains("Message Found (ID: ID001)"));

        // Not Found
        String resultNotFound = Message.searchMessageByID("ID999");
        assertEquals("Error message expected for not found ID.", "Error: Message ID 'ID999' not found.", resultNotFound);
    }
    
    @Test
    public void testSearchMessagesByRecipient_FoundAndSpecificLogic() {
        // This test must use the exact data that triggers the custom fixed logic in the method
        String recipient = "+27838884567";
        Message.addTestMessage(recipient, "It is dinner time!", "Sent", "ID1", "HSH1");
        Message.addTestMessage(recipient, "Where are you? You are late! I have asked you to be on time.", "Sent", "ID2", "HSH2");
        Message.addTestMessage(recipient, "Ok, I am leaving without you.", "Sent", "ID3", "HSH3"); // This message is intentionally skipped by the FIX in the original code's logic

        String expected = "The system returns:\n\"It is dinner time!\" \"Where are you? You are late! I have asked you to be on time.\", \"Ok, I am leaving without you.\"";
        
        assertEquals("Recipient search should match the hardcoded/fixed combined output.", expected, Message.searchMessagesByRecipient(recipient));
    }

    @Test
    public void testDeleteMessageByHash_Successful() {
        Message.addTestMessage("+1", "Message One", "Sent", "ID1", "HSH1");
        Message.addTestMessage("+2", "Message Two (to delete)", "Stored", "ID2", "HSH2");
        
        assertEquals("Initial processed messages count should be 2.", 2, Message.processedMessages.size());
        
        String result = Message.deleteMessageByHash("HSH2");
        
        String expected = "The system returns:\nMessage \"Message Two (to delete)\" successfully deleted.";
        assertEquals("Successful deletion message expected.", expected, result);
        assertEquals("Processed messages count should be 1 after deletion.", 1, Message.processedMessages.size());
        assertFalse("Hash should be removed from the list.", Message.messageHashes.contains("HSH2"));
    }

    @Test
    public void testDisplaySentMessagesReport() {
        Message.addTestMessage("+1", "Msg Sent 1", "Sent", "ID1", "HSH1");
        Message.addTestMessage("+2", "Msg Stored 2", "Stored", "ID2", "HSH2");
        
        String result = Message.displaySentMessagesReport();
        
        assertTrue("Sent message should be present.", result.contains("Hash: HSH1"));
        assertFalse("Stored message should NOT be present in Sent Report.", result.contains("Hash: HSH2"));
    }
}